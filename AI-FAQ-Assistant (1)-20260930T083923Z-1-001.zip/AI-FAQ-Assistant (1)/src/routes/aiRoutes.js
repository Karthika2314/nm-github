const express = require("express");

const { generateAIFAQ } = require("../controllers/aiController");

const router = express.Router();

router.post("/generate-faq", generateAIFAQ);

module.exports = router;