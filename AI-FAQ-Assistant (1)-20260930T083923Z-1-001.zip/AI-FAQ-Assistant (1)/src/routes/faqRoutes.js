const express = require("express");
const authMiddleware = require("../middleware/authMiddleware");

const {
    getFAQs,
    getFAQById,
    createFAQ,
    updateFAQ,
    deleteFAQ,
    searchFAQs
} = require("../controllers/faqController");

const router = express.Router();

// Test protected route
router.get("/test", authMiddleware, (req, res) => {
    res.json({
        message: "FAQ route is working",
        user: req.user
    });
});

// Get all FAQs
router.get("/", getFAQs);

// Search FAQs
router.get("/search", searchFAQs);

// Get FAQ by ID
router.get("/:id", getFAQById);

// Create FAQ
router.post("/", authMiddleware, createFAQ);

// Update FAQ
router.put("/:id", authMiddleware, updateFAQ);

// Delete FAQ
router.delete("/:id", authMiddleware, deleteFAQ);

module.exports = router;