const { GoogleGenAI } = require("@google/genai");

const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY
});

const generateFAQ = async (topic) => {
  const response = await ai.models.generateContent({
    model: "gemini-2.5-flash",
    contents: `Create 5 frequently asked questions and answers about: ${topic}.
Return the result in simple JSON format with this structure:
[
  {
    "question": "Question here",
    "answer": "Answer here"
  }
]`
  });

  return response.text;
};

module.exports = {
  generateFAQ
};