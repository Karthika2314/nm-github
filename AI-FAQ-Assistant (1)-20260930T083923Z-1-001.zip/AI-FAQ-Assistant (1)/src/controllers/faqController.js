const FAQ = require("../models/FAQ");

// ===============================
// CREATE FAQ
// ===============================
const createFAQ = async (req, res) => {
  try {
    const { question, answer, category } = req.body;

    if (!question || !answer) {
      return res.status(400).json({
        message: "Question and answer are required"
      });
    }

    const faq = await FAQ.create({
      question,
      answer,
      category,
      createdBy: req.user.id
    });

    res.status(201).json({
      message: "FAQ created successfully",
      faq
    });

  } catch (error) {
    console.error("CREATE FAQ ERROR:", error);

    res.status(500).json({
      message: "Failed to create FAQ",
      error: error.message
    });
  }
};


// ===============================
// GET ALL FAQs
// ===============================
const getFAQs = async (req, res) => {
  try {
    const faqs = await FAQ.find().sort({ createdAt: -1 });

    res.status(200).json({
      success: true,
      count: faqs.length,
      data: faqs
    });

  } catch (error) {
    console.error("GET FAQ ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch FAQs",
      error: error.message
    });
  }
};


// ===============================
// SEARCH FAQs
// ===============================
const searchFAQs = async (req, res) => {
  try {
    const q = req.query.q || "";

    console.log("FAQ SEARCH QUERY:", q);

    const faqs = await FAQ.find({
      $or: [
        {
          question: {
            $regex: q,
            $options: "i"
          }
        },
        {
          answer: {
            $regex: q,
            $options: "i"
          }
        }
      ]
    });

    console.log("FAQ SEARCH RESULT:", faqs.length);

    res.status(200).json({
      success: true,
      count: faqs.length,
      data: faqs
    });

  } catch (error) {
    console.error("FAQ SEARCH REAL ERROR:", error);

    res.status(500).json({
      success: false,
      message: "Failed to fetch FAQ",
      error: error.message
    });
  }
};


// ===============================
// GET SINGLE FAQ
// ===============================
const getFAQById = async (req, res) => {
  try {
    const faq = await FAQ.findById(req.params.id);

    if (!faq) {
      return res.status(404).json({
        message: "FAQ not found"
      });
    }

    res.status(200).json(faq);

  } catch (error) {
    console.error("GET FAQ BY ID ERROR:", error);

    res.status(500).json({
      message: "Failed to fetch FAQ",
      error: error.message
    });
  }
};


// ===============================
// UPDATE FAQ
// ===============================
const updateFAQ = async (req, res) => {
  try {
    const { question, answer, category } = req.body;

    const faq = await FAQ.findByIdAndUpdate(
      req.params.id,
      {
        question,
        answer,
        category
      },
      {
        new: true,
        runValidators: true
      }
    );

    if (!faq) {
      return res.status(404).json({
        message: "FAQ not found"
      });
    }

    res.status(200).json({
      message: "FAQ updated successfully",
      faq
    });

  } catch (error) {
    console.error("UPDATE FAQ ERROR:", error);

    res.status(500).json({
      message: "Failed to update FAQ",
      error: error.message
    });
  }
};


// ===============================
// DELETE FAQ
// ===============================
const deleteFAQ = async (req, res) => {
  try {
    const faq = await FAQ.findByIdAndDelete(req.params.id);

    if (!faq) {
      return res.status(404).json({
        message: "FAQ not found"
      });
    }

    res.status(200).json({
      message: "FAQ deleted successfully"
    });

  } catch (error) {
    console.error("DELETE FAQ ERROR:", error);

    res.status(500).json({
      message: "Failed to delete FAQ",
      error: error.message
    });
  }
};


// ===============================
// EXPORT FUNCTIONS
// ===============================
module.exports = {
  createFAQ,
  getFAQs,
  getFAQById,
  updateFAQ,
  deleteFAQ,
  searchFAQs
};