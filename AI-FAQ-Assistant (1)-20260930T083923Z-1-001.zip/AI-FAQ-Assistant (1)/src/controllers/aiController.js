const { generateFAQ } = require("../services/geminiService");

const generateAIFAQ = async (req, res) => {
  try {
    const { topic } = req.body;

    if (!topic) {
      return res.status(400).json({
        message: "Topic is required"
      });
    }

    const result = await generateFAQ(topic);

    res.status(200).json({
      message: "AI FAQ generated successfully",
      result
    });

  } catch (error) {
    console.error("AI generation error:", error);

    res.status(500).json({
      message: "Failed to generate AI FAQ",
      error: error.message
    });
  }
};

module.exports = {
  generateAIFAQ
};